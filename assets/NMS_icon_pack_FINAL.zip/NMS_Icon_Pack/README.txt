NO MAN'S SKY — SCI-FI ICON PACK
================================
Free fan-made icon pack inspired by No Man's Sky.
Built by Tony  •  nms-sci-fi-theme-pack.netlify.app

WHAT'S INSIDE
-------------
Each icon is provided in multiple square sizes so it works on any device:
  /512x512  — high-res phones, desktop, Linux .desktop launchers
  /256x256  — most Android launchers / Nova / Smart Launcher
  /128x128  — older / lightweight launchers
  /64x64    — toolbar & small-tile sizes
  /48x48    — legacy Android (mdpi/hdpi)
  (a few icons also include 32x32 / 16x16 for tiny uses)

  /special  — named lore icons (Atlas Pass, Sentinel variants, Gek, Korvax,
              Vy'keen, Apollo, Artemis, Nada, Polo, Telamon, The Construct,
              Harmonic Seal, Mission Portal, etc.) — single high-res size.

HOW TO APPLY
------------
Android:  Use a custom launcher (Nova, Lawnchair, Smart Launcher). Long-press
          an app > Edit > tap the icon > Gallery/Custom > pick a PNG.
          For best results use the 256x256 or 512x512 versions.
iPhone:   Shortcuts app > add app to Home Screen > choose a 512x512 PNG.
Windows:  Right-click shortcut > Properties > Change Icon (use 256 or 512).
Mac:      Get Info on app > drag a 512x512 PNG onto the icon thumbnail.
Linux:    Point the .desktop file's Icon= line at a 512x512 PNG.

manifest.json lists every icon and the sizes available for each.

This is a free, non-commercial fan project and is not affiliated with
Hello Games. No Man's Sky is a trademark of Hello Games.
